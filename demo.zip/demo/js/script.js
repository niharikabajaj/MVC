function display_value() {

    //var para1 = document.getElementById('p1');
    var name = document.getElementById('namebox');
    //var para2 = document.getElementById('p2');
    var address = document.getElementById('addbox');

    if (name.value == "") {
        alert("Please enter your name.");
        name.focus();
        //return false;
    }
    if (address.value == "") {
        alert("Please enter the address.")
        address.focus();
        //return false;
    }

    if (name.value != "" && address.value != "") {
        //para1.innerHTML = name.value;
        //para2.innerHTML = address.value;
        var table02 = document.getElementById('table2');
        var row1 = table02.insertRow(1);
        var cell1 = row1.insertCell(0);
        var cell2 = row1.insertCell(1);
        cell1.innerHTML = name.value;
        cell2.innerHTML = address.value;
    }

    var ele = document.getElementById('sel');
    msg.innerHTML = 'Selected ID: <b>' + ele.options[ele.selectedIndex].text + '&nbsp </b>' +
        'MODEL: <b>' + ele.value + '</b>';

    var colors = document.getElementsByName('color');
    var col_value;
    for (var i = 0; i < colors.length; i++) {
        if (colors[i].checked) {
            col_value = colors[i].value;
            document.getElementById("color_name").innerHTML = col_value;
        }
    }

    var mtype = document.getElementsByName('mtype');
    var type_value = "";
    for (var i = 0; i < mtype.length; i++) {
        if (mtype[i].checked) {
            type_value += mtype[i].value + ' ,';
        }
        var final_value = type_value.slice(0, -1);
    }
    document.getElementById("type_name").innerHTML = final_value;

}

//dropdown function...

function populateSelect() {
    // THE JSON ARRAY.
    var model = [
        {
            "ID": "101",
            "Type": "Model T"
        },
        {
            "ID": "104",
            "Type": "Model A"
        },
        {
            "ID": "106",
            "Type": "Model M"
        },
        {
            "ID": "107",
            "Type": "Model Th"
        },
    ];

    var ele = document.getElementById('sel');
    for (var i = 0; i < model.length; i++) {
        // POPULATE SELECT ELEMENT WITH JSON.
        ele.innerHTML += '<option value="' + model[i]['Type'] + '">' + model[i]['ID'] + '</option>';
    }

    var ele1 = document.getElementById('chkbox');
    for (var i = 0; i < model.length; i++) {
        // POPULATE SELECT ELEMENT WITH JSON.
        
        ele1.innerHTML += '<input type="checkbox"  id="'+ model[i]['ID']+'" value="'+ model[i]['ID']+'"> '+ model[i]['Type'];
    }
}

