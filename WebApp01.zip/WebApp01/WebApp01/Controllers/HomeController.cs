﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApp01.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult MainView()
        {
            return View();
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult View2()
        {
            return View();
        }

        public ActionResult View3()
        {
            ViewBag.name = "ABC ViewBag.";
            return View();
        }

        public ActionResult View5()
        {
            return View("View4");
        }

        public ActionResult View6()
        {
            ViewData["Name"] = "DEF ViewData.";
            return View();
        }

        public ActionResult View7()
        {
            TempData["Date"] = DateTime.Now.ToString();
            return View();
        }

        public ActionResult ActionParameter(string id)
        {
            ViewBag.id = id;
            return View();
        }

        public ActionResult JqueryForm()
        {
            return View();
        }

        public ActionResult JavaScriptForm()
        {
            return View();
        }
    }
}