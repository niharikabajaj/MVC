﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using baseClass;

namespace Console1
{
    public class Base1 : Classbase
    {
        public void hello()
        {
            Console.WriteLine("Hello, World!");
            Console.WriteLine(" ");
            Classbase obj1 = new Classbase();
            obj1.book_details();
            Console.ReadKey();
        }

        public int calc(int e, int f)
        {
            return (e * f);
        }

        public void word(int x)
        {
            int[] num = new int[5];
            for (int i = 0; i < num.Length; i++)
            {
                num[i] = x;
                Console.Write(num[i]);
                {
                    if (num[i] <= 500)
                    {
                        Console.WriteLine(" Less than 500.");
                    }
                    else
                    {
                        Console.WriteLine(" Greater than 500.");
                    }
                    x += x;
                }
            }
            Console.WriteLine(" ");
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Enter number 1");
            string p = Console.ReadLine();
            Console.WriteLine("Enter number 2");
            string q = Console.ReadLine();
            Console.WriteLine(" ");
            int s = Convert.ToInt32(p);
            int t = Convert.ToInt32(q);
            Base1 n1 = new Base1();
            Base1 n2 = new Base1();
            int res = n1.calc(s, t);
            n2.word(res);
            n1.hello();
        }
    }
}
