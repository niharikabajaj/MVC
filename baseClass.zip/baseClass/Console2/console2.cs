﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console2
{
    class Program
    {
        public interface Book1
        {
            void genre();

        }

        public interface Book2
        {
            void genre2();
        }
        public class Fiction : Book1, Book2
        {
            public void genre()
            {
                Console.WriteLine("the book belongs to fiction genre...");
            }


            public void genre2()
            {
                Console.WriteLine("the book belongs to non-fiction genre...");
            }

            public void m1()
            {
                Console.WriteLine("the book belongs to non-fiction genre...");
            }
       
            public static void Main(string[]agrs)
            {
                Fiction f = new Fiction();
                f.genre();
                f.genre2();
                f.m1();
                Console.ReadKey();
            }
        }
    }
}
