﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baseClass
{
    public class Classbase2
    {
        public virtual int addnum(int a, int b)
        {
            return (a + b);
        }
        public int addnum(int a, int b, int c)
        {
            return (a + b + c);
        }
    }
}
