﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baseClass
{
    public class Classbase : Classbase2
    {
        struct Books
        {
            public string title;
            public string author;
            public string subject;
            public int book_id;
        };

        public override int addnum(int a, int b)
        {
            return a * b;
        }
            public void book_details()
            { 
                Books Book1;   
                Books Book2;  

                Book1.title = "Title 1";
                Book1.author = "Author 12";
                Book1.subject = "Subject A";
                Book1.book_id = 101;

                Book2.title = "Title 2";
                Book2.author = "Author 9";
                Book2.subject = "Subject K";
                Book2.book_id = 105;

                Console.WriteLine("Book 1 title : {0}", Book1.title);
                Console.WriteLine("Book 1 author : {0}", Book1.author);
                Console.WriteLine("Book 1 subject : {0}", Book1.subject);
                Console.WriteLine("Book 1 book_id : {0}", Book1.book_id);
                Console.WriteLine(" ");

                Console.WriteLine("Book 2 title : {0}", Book2.title);
                Console.WriteLine("Book 2 author : {0}", Book2.author);
                Console.WriteLine("Book 2 subject : {0}", Book2.subject);
                Console.WriteLine("Book 2 book_id : {0}", Book2.book_id);
                Console.WriteLine(" ");

                Classbase2 obj2 = new Classbase2();
                Classbase obj = new Classbase();
                int res = obj2.addnum(5, 8);
                Console.WriteLine("method addnum with 2 variables : " + res);
                int res2 = obj2.addnum(3, 4, 5);
                Console.WriteLine("method addnum with 3 variables : " + res2);
                int resn = obj.addnum(5, 8);
                Console.WriteLine("method addnum with 2 variables overriding : " + resn);

            Console.ReadKey();
            }

        
    }
}
