﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console3
{
    class console3
    {
        abstract class buildingParent
        {
            public abstract void entranceM1();
            public void floorsM2()
            {
                Console.WriteLine("the number of floors is Z.");
            }
        }
        class apartmentChild : buildingParent
        {
            public override void entranceM1() { Console.WriteLine("It has N entrances."); }
        }
        static void Main(string[] args)
        {
            apartmentChild Apa = new apartmentChild();
            buildingParent One = Apa;
            Apa.entranceM1();
            One.floorsM2();
            Console.ReadKey();
        }
    }
}
