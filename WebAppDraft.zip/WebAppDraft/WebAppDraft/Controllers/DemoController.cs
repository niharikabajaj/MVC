﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebAppDraft.Controllers
{
    public class DemoController : Controller
    {
        // GET: Demo
        public ActionResult IndexDynamic()
        {
            Models.DemoDynamic demo = new Models.DemoDynamic()
            {
                Id = "ABC",
                Name = 101,
            };
            return View(demo);
        }

        public ActionResult IndexStrongly()
        {
            Models.DemoStrongly demo = new Models.DemoStrongly()
            {
                Id = 101,
                Name = "ABC",
            };
            return View(demo);
        }
    }
}