﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebAppDraft.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult MainView()
        {
            return View();
        }

        public ActionResult ActionParameter(string id)
        {
            ViewBag.id = id;
            return View();
        }

        public ActionResult Test(string id)
        {
            return View();
        }

        public ActionResult JqueryForm()
        {
            return View();
        }

        public ActionResult JavaScriptForm()
        {
            return View();
        }
    }
}