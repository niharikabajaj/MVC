﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApp02.Models;

namespace WebApp02.Controllers
{
    public class DefaultController : Controller
    {
        // GET: Default
        public ActionResult HomePage(Properties prop)
        {
            List<Properties> obj = new List<Properties>();
            if (Session["userCollection"] != null)
            {
                var objSession = Session["userCollection"] as List<Properties>;
                obj.AddRange(objSession);
                obj.Add(prop);
                Session["userCollection"] = obj;
            }
            else
            {
                obj.Add(prop);
                Session["userCollection"] = obj;
            }
            return View("HomePage");
        }
            

        public ActionResult DataPage(Properties prop)
        {
            return View();
        }
    }
}