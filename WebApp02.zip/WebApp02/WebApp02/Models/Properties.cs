﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApp02.Models
{
    public class Properties
    {
        public string First_name
        {
            get;    set;
        }
        public string Last_name
        {
            get;    set;
        }
        public string Gender
        {
            get;    set;
        }
    }
}